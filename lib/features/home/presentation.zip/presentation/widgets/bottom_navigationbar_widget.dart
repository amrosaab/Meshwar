import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../../common/common.dart';
import '../../../../../../core/utils/custom_text.dart';
import '../../../../../../l10n/app_localizations.dart';
import '../../application/home_bloc.dart';
import '../../domain/models/user_details_model.dart';

class BottomNavigationbarWidget extends StatefulWidget {
  final int index;
  final UserDetail userData;
  final Function(int) onTap;

  const BottomNavigationbarWidget({
    super.key,
    required this.index,
    required this.userData,
    required this.onTap,
  });

  @override
  State<BottomNavigationbarWidget> createState() =>
      _BottomNavigationbarWidgetState();
}

class _BottomNavigationbarWidgetState extends State<BottomNavigationbarWidget> {
  late int _selectedIndex;

  @override
  void initState() {
    _selectedIndex = widget.index;
    super.initState();
  }

  @override
  void didUpdateWidget(covariant BottomNavigationbarWidget oldWidget) {
    if (oldWidget.index != widget.index) {
      setState(() {
        _selectedIndex = widget.index;
      });
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    MediaQuery.sizeOf(context);

    final bgColor = isDark
        ? AppColors.bottomNavigationBarColorDark
        : AppColors.bottomNavigationBarColor;
    final shadowColor = isDark
        ? AppColors.bottomNavigationBarShadowColorDark
        : AppColors.bottomNavigationBarShadowColor;

    return Padding(
      padding: const EdgeInsets.all(14),
      child: Container(
        height: 70,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: shadowColor,
              spreadRadius: 1,
              blurRadius: 15,
              offset: Offset.zero,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: _buildNavItem(
                index: 0,
                iconPath: AppImages.home,
                label: AppLocalizations.of(context)!.home,
                isDark: isDark,
              ),
            ),
            Expanded(
              child: _buildNavItem(
                index: 1,
                iconData: Icons.history,
                label: AppLocalizations.of(context)!.history,
                isDark: isDark,
              ),
            ),
            if (widget.userData.showWalletFeatureOnMobileApp == '1')
              Expanded(
                child: _buildNavItem(
                  index: 2,
                  iconPath: AppImages.walletMenu,
                  label: AppLocalizations.of(context)!.wallet,
                  isDark: isDark,
                ),
              ),
            Expanded(
              child: _buildNavItem(
                index: 3,
                iconPath: AppImages.user,
                label: AppLocalizations.of(context)!.myAccount,
                isDark: isDark,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    String? iconPath,
    IconData? iconData,
    required String label,
    required bool isDark,
  }) {
    final isSelected = _selectedIndex == index;

    final selectedColor = isDark
        ? AppColors.bottomNavigationBarSelectedColorDark
        : AppColors.primary;
    final unselectedColor = isDark
        ? AppColors.bottomNavigationBarUnSelectedColorDark
        : AppColors.bottomNavigationBarUnSelectedColor;

    return GestureDetector(
      onTap: () {
        if (_selectedIndex == index) return;
        widget.onTap(index);
        if (index == 0) {
          context.read<HomeBloc>().add(GetDirectionEvent());
          context.read<HomeBloc>().add(GetUserDetailsEvent());
        }
      },
      child: Container(
        height: 48,
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOut,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: isSelected
                    ? selectedColor.withOpacity(0.12)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: iconPath != null
                  ? Image.asset(
                iconPath,
                height: 20,
                width: 20,
                color: isSelected ? selectedColor : unselectedColor,
              )
                  : Icon(
                iconData,
                size: 20,
                color: isSelected ? selectedColor : unselectedColor,
              ),
            ),
            const SizedBox(height: 4),
            MyText(
              text: label,
              textStyle: Theme.of(context).textTheme.bodyMedium!.copyWith(
                color: isSelected ? selectedColor : unselectedColor,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}